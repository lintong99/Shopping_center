<!-- 1.<script setup>
import HelloWorld from './components/HelloWorld.vue';
import Button from './components/Button.vue';
import Books from './components/Books.vue';
</script>

<template>
    <Button ></Button>
    <Books></Books>
    <div>
    <HelloWorld msg="你好"/>
    <HelloWorld msg="这是父亲组件传过来的" />
    <HelloWorld msg="这是父亲组件传过来的" />
    <HelloWorld msg="123124" />
    <HelloWorld msg="asdfasfdsa" />
    <HelloWorld msg="14314" />
    <HelloWorld msg="345" />
  </div>
    <div id="#app" class="a"></div>
    
</template>

<style scoped>

  .a{
    width: 1000px;
    height: 100%;
    background-color: rgb(8, 243, 255);
    flex-wrap: wrap;
    background-origin:content-box;
  
  }
  .button{
    width: 50px;
    height: 50px;
    background-color: rgba(97, 220, 16, 0.726);
  }
</style> -->
<!-- 2.<script setup>

</script>


<template>
  <div>
    <div>
      <router-link to="/home">首页</router-link> | 
      <router-link to="/about">关于</router-link> | 
      <router-link to="/mine">我的</router-link>
    </div>
    <router-view></router-view>
  </div>
</template>


<style scoped>
.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.vue:hover {
  filter: drop-shadow(0 0 2em #42b883aa);
}
</style> -->

<script setup>
import { Tabbar as VanTabbar, TabbarItem as VanTabbarItem} from 'vant';

</script>
<template>
<div class="iframe">
  <router-view />
  <van-tabbar  active-color="#ee0a24" route>
    <van-tabbar-item replace to="/home" icon="home-o">首页</van-tabbar-item>
    <van-tabbar-item replace to="/about" icon="search">分类</van-tabbar-item>
    <van-tabbar-item replace to="/cart" icon="cart-o">购物车</van-tabbar-item>
    <van-tabbar-item replace to="/mine" icon="manager-o">我的</van-tabbar-item>
  </van-tabbar>
</div>
</template>

<style scoped>
.iframe{
  width: 100%;
}

</style>
