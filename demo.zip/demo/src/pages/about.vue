<script setup>
import { ref } from 'vue';
import { useRouter, } from "vue-router";
import { Search as VanSearch,Tag as VanTag , Button as VanButton,Col as VanCol,Card as VanCard,Tabs as VanTabs,Tab as VanTab} from 'vant';

const router = useRouter();

const activeIndex = ref(0);

const tabItems = [
  { title: "推荐" },
  { title: "Xiaomi手机" },
  { title: "Redmi手机" },
  { title: "手机配件" },
  { title: "电脑平板" },
  { title: "智能穿戴" },
  { title: "智能家居" },
  { title: "日用百货" },
];

const items1 = [
[
  { title: "Xiaomi 13 限定纪念色", price: "￥4999.00 起", image: "https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202305061614_38dd34045a97f58bd1d5c0538b5b2522.png?w=800&h=800" },
  { title: "Redmi K50 至尊纪念版", price: "￥2699.00 起" ,image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202208101508_df890f7fafc29921ded695b2af591190.png?w=800&h=800"},
  { title:"小米移动电源3",price:"￥119.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/bc2153ce733976b53df22a51cb28012b.png?w=800&h=800"},
  { title:"手环8 NFC",price:"￥279.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/af68392a88814f97c880896ea367eb17.png?thumb=1&q=90&w=120&h=120"},
  { title:"Xiaomi Pad 6 Pro",price:"￥2499.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202304141132_bce7b9915481feb1db75d74364f17691.png?w=800&h=800"},
  { title: "Xiaomi 13", price: "￥3999.00 起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202211292356_df7c11aed8238f8ea6ca0c28d7713818.png?w=800&h=800"},
],
[
  { title: "Xiaomi 13 Ultra", price: "￥5999.00 起", image: "https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202304171459_dd35f1e6215da63c356e352d4d398ce6.png?w=800&h=800" },
  { title: "Xiaomi 13 Pro", price: "￥4999.00 起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202211292343_1fb2e2ce696643e2e9e863f69cdaf781.png?w=800&h=800"},
  { title: "Xiaomi 13", price: "￥3999.00 起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202211292356_df7c11aed8238f8ea6ca0c28d7713818.png?w=800&h=800"},
  { title: "Xiaomi 12S Pro", price: "￥3199.00 起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202207012000_0b9df066c110f201154013ac373df1d9.png?w=800&h=800" },
  { title: "Xiaomi 12S", price: "￥2899.00 起" ,image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202207012026_c5e0f5b141c708d84a44764d066717af.png?w=800&h=800"},
  { title: "Xiaomi 12 Pro", price: "￥2999.00 起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/bec639601906ed7649970c6ab311f992.png?w=800&h=800" },
],
[ 
  { title: "Redmi K60 Pro", price: "￥2899.00 起", image: "https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202212261456_d20c10733b97c9395bd05c97092a4120.png?w=800&h=800" },
  { title: "Redmi K60", price: "￥2299.00 起" ,image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202212261456_d20c10733b97c9395bd05c97092a4120.png?w=800&h=800"},
  { title: "Redmi K50 至尊纪念版", price: "￥2699.00 起" ,image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202208101508_df890f7fafc29921ded695b2af591190.png?w=800&h=800"},
  { title: "Redmi K50 Pro", price: "￥2999.00 起" ,image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/bfe68c63caca6622d1673efa7d7e7a7d.png?w=800&h=800"},
  { title: "Redmi K50", price: "￥2099.00 起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/268eb39e48af6bb86e448e143a119eea.png?w=800&h=800" },
  { title: "Redmi K40S", price: "￥1799.00 起" ,image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/8705d355125196baa7f8c2df87936290.png?w=800&h=800"},
],
[
  {title:"小米立式无线充",price:"￥149.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202207041944_8695569a76c13b3a666594bb67e644d0.png?w=800&h=800"},
  {title:"小米充电器",price:"￥29.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/f794e6cf74dc9e3c929f49133ad8a0ee.png?w=800&h=800"},
  {title:"小米Type-c快充数据线",price:"￥27.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/303e758bd1de9139f4b46dcc08465ff7.png?w=800&h=800"},
  {title:"小米移动电源3",price:"￥119.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/bc2153ce733976b53df22a51cb28012b.png?w=800&h=800"},
  {title:"小米13保护壳",price:"￥99.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202212081530_1095a1df2903620ddb08048c6e367fe9.png?w=800&h=800"},
  {title:"小米支架式自拍杆",price:"￥79.00起",image:"https://cdn.cnbj0.fds.api.mi-img.com/b2c-mimall-media/c71af618288a23c03873a86fca2edaac.png?w=800&h=800"},
],
[
  {title:"Xiaomi Pad 6 Pro",price:"￥2499.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202304141132_bce7b9915481feb1db75d74364f17691.png?w=800&h=800"},
  {title:"Xiaomi Pad 6",price:"￥1899.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202304141120_65077b4c5d2ae1e8472bc97cc8968b42.png?w=800&h=800"},
  {title:"小米平板5 Pro 12.4",price:"￥1899.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202208101822_61eaf5f69fdc3e6c2fa0eb570e091d4d.png?w=800&h=800"},
  {title:"小米平板5",price:"￥1999.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/6285ac65260e72ebfbff4f47e9072c2c.png?w=800&h=800"},
  {title:"小米平板5 Pro",price:"￥1799.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/9d31e054a36f729c53b25bffab12686c.png?w=800&h=800"},
  {title:"小米平板5 Pro 5G",price:"￥2799.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/b37dddd20d16c5814346db9e18eec936.png?w=800&h=800"},
],
[
  {title:"Buds4 活力版",price:"￥99.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/36de2848cabb8783ec63e36318130a3f.png?thumb=1&q=90&w=120&h=120"},
  {title:"手环8",price:"￥239.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/5f5e4c9035abbe5600d3964b93f63fa2.png?thumb=1&q=90&w=120&h=120"},
  {title:"手环8 NFC",price:"￥279.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/af68392a88814f97c880896ea367eb17.png?thumb=1&q=90&w=120&h=120"},
  {title:"手表3 青春版",price:"￥399.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/10c4979f7c2802f89eb80ea2d77b52bd.png?thumb=1&q=90&w=120&h=120"},
  {title:"Redmi watch 3",price:"￥469.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/69fec97e1a41e998d032509ee72ae07c.png?thumb=1&q=90&w=120&h=120"},
  {title:"Redmi 手环 2",price:"￥149.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/417c0a454d1c09c8846a5b583740c9f1.png?thumb=1&q=90&w=120&h=120"},
],
[
  {title:"Xiaomi Sound Pro",price:"￥999.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202212101232_fd70d0b1df7909b4a38d5158378ef0c9.png?w=800&h=800"},
  {title:"Xiaomi Sound",price:"￥499.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/ec6d0012830eb403e3530f70b9bd2656.png?w=800&h=800"},
  {title:"小米小爱音响 Play",price:"￥99.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202306151144_5d2a2b6de773b3bf9d024967e818b57e.png?w=800&h=800"},
  {title:"Xiaomi 智能家庭屏6",price:"￥399.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202207211953_2dc13dea3dc4891604e06724e28f7a85.png?w=800&h=800"},
  {title:"小米小爱触屏音箱",price:"￥269.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/2e5f76bdf1ce59b3a26b02457d48f5f0.png?w=800&h=800"},
  {title:"小米小爱音箱 儿童版",price:"￥299.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202304041442_59c24577798c768e350ad20121b5cde8.jpg?w=800&h=800"},
],
[
  {title:"自动折叠伞",price:"￥79.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202306130948_b0e2d2bf32c50bd0556c1c3a747393cc.png?w=800&h=800"},
  {title:"米家智能驱蚊器",price:"￥69.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202306130948_b0e2d2bf32c50bd0556c1c3a747393cc.png?w=800&h=800"},
  {title:"米家无线洗车机",price:"￥399.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202301121823_99428890dddd437db54e380ef356f1d1.jpg?w=800&h=800"},
  {title:"米家保温杯 口袋版",price:"￥49.00起",image:"https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202211231453_feb85fbec42a890015224cbed7825a30.png?w=800&h=800"},
  {title:"米家毛球修剪器",price:"￥39.90起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/daa6f98dda2b994a59d94e2d0f3e1e07.png?w=800&h=800"},
  {title:"小米巨能写中性笔10支",price:"￥9.90起",image:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/cb92ee260f1acae1f92e8f130423471a.png?w=800&h=800"},
],
];
const handleTabChange = (index) => {
  activeIndex.value = index;
};

const handleBuyClick = (items1) => {
  router.push('/cart');
};

</script>
<template>
 <van-search v-model="searchKeyword" placeholder="请输入搜索关键词" />
  <div>
    <van-tabs v-model="activeIndex" @change="handleTabChange" scrollspy sticky>
      <van-tab v-for="(item, index) in tabItems" :key="index" :title="item.title">
        <div class="card">
          <div v-for="(item1, index) in items1[index]" :key="index" class="frame" >
            <img :src="item1.image" class="image" />
            <div class="context">
              <div class="title">
                <div>{{ item1.title }}</div>
              </div>
              <div class="price">{{ item1.price }}</div>
            </div>
            <div>   
              <div class="button">
                <van-button icon="cart-circle-o" 
                round type="success" 
                size="mini"
                color="#dc5b2c"  
                @click="handleBuyClick(item1)"
                >购买</van-button>
              </div>
            </div>
          </div>
        </div> 
      </van-tab>
    </van-tabs>
    
  </div>
</template>

<style scoped>
.read-the-docs {
  color: #888;
}

.card {
  width: 370px;
  height: 630px;

  margin-bottom: 50px;
}

.frame {
  display: flex;
  flex-direction: row;
  width: 350px;
  float: right ;
  margin-top: 10px;
}

.title {
  display: flex;
  flex-direction: row;
  text-align: left;
  font-size: 14px;
  margin-top: 9px;
  margin-left: 5px;
  font-weight:bold;
}

.price {
  margin-top: 2px;
  display: flex;
  flex-direction: row;
  font-size: 14px;
  margin-top: 26px;
  color: #d30000;
}

.context {
  display: flex;
  flex-direction: column;
  margin-left: 12px;
  margin-top: 16px;
  width: 140px;
}

.button {
  margin-top: 60px;
  margin-left: 20px;
  color: #dc5b2c;
  border-radius: 4px;
  text-align: center;
  margin-bottom: 9px;
}

.image {
  border: 2px solid #ffffff;
  width: 110px;
  height: 80px;
  background-size: cover;
  background-repeat: no-repeat;
  margin-top: 10px;
}
</style>
