<script setup>
 import {NavBar as VanNavBar,Grid as VanGrid,GridItem as VanGridItem,Search as VanSearch} from 'vant';
const onClickSch = () => history.back();
defineProps({
  msg: String,
})

</script>

<template>
<div>
  <van-nav-bar
 title="搜索商品名称"
  left-text="返回"
  left-arrow
  @click-left="onClickSch"
/>
<van-search
  v-model="value"
  show-action
  
  placeholder="搜索商品名称"
  @search="onSearch"
>
  <template #action>

  </template>
</van-search>

<van-grid :column-num="2">
  <van-grid-item text="全部商品" />
  <van-grid-item text="空调" />
  <van-grid-item text="手机" />
  <van-grid-item text="冰箱" />
  <van-grid-item text="红米" />
  <van-grid-item text="洗衣机" />
  <van-grid-item text="xiaomi迷你主机" />
  <van-grid-item text="投影仪" />
</van-grid>

</div>
 
</template>


<style scoped>

</style>
