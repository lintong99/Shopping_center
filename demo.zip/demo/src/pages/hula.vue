<script setup>
defineProps({
  msg: String,
})
import { ref,reactive } from 'vue';
import {Cell as VanCell,ActionSheet as VanActionSheet,Swipe as VanSwipe,SwipeItem as VanSwipeItem,Button as VanButton} from 'vant';

const images = reactive([
      "image1",])
const show = ref(false);
    const actions=[
      { name: '我的积分' },
      { name: '卡券' },
      { name: '米币' },
    ];
    
    const onSelect = (item) => {
      // 默认情况下点击选项时不会自动收起
      // 可以通过 close-on-click-action 属性开启自动收起
      show.value = false;
      showToast(item.name);
    };
    const onClickLeft = () => history.back();
function onClickButton(){
   router.push('/mine')
 }

    </script>

<template>

    <van-button to="/mine">返回</van-button>
    <van-swipe class="my-swipe" :autoplay="3000" indicato-color="white">
  <van-swipe-item v-for="(item,index) in images">
    <div :class="item"></div>
    <div class="image2"></div>
  </van-swipe-item>
  </van-swipe>
    <van-cell is-link title="相关查询" @click="show = true" />
   <van-action-sheet v-model:show="show" :actions="actions" @select="onSelect" />
   <van-cell  title="实名认证"  icon="manager" @click="show = true" />
   <van-action-sheet v-model:show="show" :actions="actions" @select="onSelect" />
   <van-cell  title="账号与安全"  icon="lock"  @click="show = true" />
   <van-action-sheet v-model:show="show" :actions="actions" @select="onSelect" />
   <van-cell  title="我的设备"  icon="graphic" @click="show = true" />
   <van-action-sheet v-model:show="show" :actions="actions" @select="onSelect" />
   <van-cell  title="帮助与客服"  icon="chat"   @click="show = true" />
   <van-action-sheet v-model:show="show" :actions="actions" @select="onSelect" />
   <van-cell  title="充值"  icon="gold-coin"  @click="show = true" />
   <van-action-sheet v-model:show="show" :actions="actions" @select="onSelect" />
   
   
    </template>
  

<style scoped>
.image2{
  height: 150px;
  background-size:cover;
  background-repeat: no-repeat;
  background-image: url('../assets/8e79921e5a7d25e9e1b8181447d8690.png');
}
.read-the-docs {
  color: #888;
}
</style>
