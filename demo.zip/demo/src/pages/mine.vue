<script setup>
defineProps({
  msg: String,
})

import {Icon as VanIcon,Cell as VanCell,CellGroup as VanCellGroup,} from 'vant';
import { ref, reactive } from 'vue';
import { useRouter } from "vue-router";
import { Grid as VanGrid,GridItem as VanGridItem ,Swipe as VanSwipe,SwipeItem as VanSwipeItem,NavBar as VanNavBar,
  Form as VanForm,Field as VanField,Button as VanButton,Popup as VanPopup,Steps as VanSteps} from 'vant';
//弹出层引用
    const show = ref(false);
    const showPopup = () => {
      show.value = true;
    };
//表单Form中用户名和密码的引用
const username = ref('');
const password = ref('');
const onSubmit = (values) => {
  console.log('submit', values);
};

const router = useRouter()
const images = reactive([
      "image1",
    ])

//（小组件）
const imagesList = reactive([
  {icon: "paid",      text:"待付款" },
  {icon: "logistics" , text:"待收货" },
  {icon: "comment-o" , text:"待评价" },
  {icon: "balance-o" , text:"退款/售后" },
])


</script>

<template>
 <!--定义页面左上角的小米商城字样--> 
  <van-nav-bar
  left-text="小米商城"
  @click-left="onClickLeft"
/>

<!--图片格式调整-->
 <van-swipe class="my-swipe" :autoplay="3000" indicato-color="white">
  <van-swipe-item v-for="(item,index) in images">
    <div :class="item"></div>
  </van-swipe-item>
</van-swipe>

<!--小组件的大小-->
<van-grid icon-size="30px">
 <van-grid-item v-for="(item,index) in imagesList" :icon="item.icon" :text="item.text" />
</van-grid>

<!--（登录/注册）代码-->

<van-cell title="（登录/注册）" is-link @click="showPopup" />
<van-popup v-model:show="show" :style="{ padding: '64px' }">请登录
  <van-form @submit="onSubmit">
  <van-cell-group inset>
    <van-field
      v-model="username"
      name="用户名"
      label="用户名"
      placeholder="用户名"
      :rules="[{ required: true, message: '请填写用户名' }]"
    />
    <van-field
      v-model="password"
      type="password"
      name="密码"
      label="密码"
      placeholder="密码"
      :rules="[{ required: true, message: '请填写密码' }]"
    />
  </van-cell-group>
  <div style="margin: 16px;">
    <van-button round block type="primary" native-type="submit">提交
    </van-button>
  </div>
</van-form>
</van-popup>


 <!-- 列表 -->
 <!--pages/mine/mine.wxml-->
 
<div class="list">
 <div class="listOne" >
    <van-cell-group>
    <van-cell title="我的订单"   icon="manager"    size="large"  is-link to="kefu" />
    <van-cell title="会员中心"   icon="vip-card"   size="large"  is-link to="hula" />
    <van-cell title="消息通知"   icon="chat"       size="large"  is-link arrow-direction="down" />
    <van-cell title="我的优惠"   icon="gem"  size="large"  is-link to="youh"/>
    <van-cell title="小米之家"   icon="wap-home"   size="large"  is-link arrow-direction="down" />
    <van-cell title="我的地址"   icon="map-marked" size="large"  is-link  to="local"/>
    <van-cell title="设置"       icon="setting"    size="large"  is-link  to="shez"/>
  </van-cell-group>
</div>
<div class="emtry"></div>
</div>

</template>

<style scoped>


.image1{
  height: 140px;
  background-size:cover;
  background-repeat: no-repeat;
  background-image: url('../assets/59b74a1db6456b0977b7b61794e8a14.png');
}

.read-the-docs {
  color: #888;
}
.emtry{
  height: 50px;
}
</style>

