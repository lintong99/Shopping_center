<script setup>
defineProps({
 msg: String,
})
import { ref } from 'vue';
import { AddressList as VanAddressList,Button as VanButton} from 'vant';


const chosenAddressId= ref('1');
    const list = [
      {
        id: '1',
        name: '付付',
        tel: '17535267477',
        address:'山西省大同市迎宾街',
        isDefault: true,
      },
      {
        id: '2',
        name: '吕布',
        tel: '13859546158',
        address:'东汉末年（五原九原）',
      },
      {
        id: '3',
        name: '鲁智深',
        tel: '15935755962',
        address:'北宋（梁山泊）',
      },
      ];
     
      const disabledList = [
      {
        id: '3',
        name: '王五',
        tel: '1320000000',
        address: '浙江省杭州市滨江区江南大道 15 号',
      },
    ];
      
    const onAdd = () => showToast('新增地址');
    const onEdit = (item, index) => showToast('编辑地址:' + index);

  
</script>
<template>
  <van-button to="/mine">返回</van-button>
<van-address-list
   v-model="chosenAddressId"
   :list="list"
   :disable-list="disabledList"
   disabled-text-="以下地址超出范围"
   default-tag-text="默认"
   @add="onAdd"
   @edit="onEdit"
   />

</template>
<style scoped>
.read-the-docs {
  color: #888;
}

</style>

