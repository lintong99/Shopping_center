<script setup>
defineProps({
 msg: String,
})
import { ref } from 'vue';
import{Steps as VanSteps,Step as VanStep,Cell as VanCell,Button as VanButton} from 'vant';
const active = ref(2);
const onClickLeft = () => history.back();
//返回主页面
function onClickButton(){
   router.push('/mine')
 }
</script>

<template>
  
    <van-button to="/mine">返回</van-button>
    <van-cell title="物流消息"   icon="cart"    />
    <van-cell title="邮政快递：773228693544181"     />
    <van-cell title="物流电话：13529864592"      />
    
<van-steps :active="active">
  <van-step>买家下单</van-step>
  <van-step>商家发货</van-step>
  <van-step>运输中</van-step>
  <van-step>派送中</van-step>
  <van-step>待取件</van-step>

</van-steps>
<van-steps direction="vertical" :active="2">
  <van-step>
    <h3>【辽宁大连市】物流状态1</h3>
    <p>2023-06-26 12:40</p>
  </van-step>
  <van-step>
    <h3>【大连市(待转件)】物流状态2</h3>
    <p>2023-06-26 16:03</p>
  </van-step>
  <van-step>
    <h3>【北京市朝阳区】物流状态3</h3>
    <p>2023-06-28 7:40</p>
  </van-step>
  <van-step>
    <h3>【山西省太原市】物流状态4</h3>
    <p>2023-06-29 12:40</p>
  </van-step>
  <van-step>
    <h3>【山西省晋中市榆次区万豪美悦新天地智创公寓】</h3>
    <p>2023-06-30 09:30</p>
  </van-step>
</van-steps>

</template>

<style scoped>

</style>
