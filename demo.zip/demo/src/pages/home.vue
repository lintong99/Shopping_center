<!-- <script setup>
import { ref, reactive } from 'vue'
import { useRouter } from "vue-router";
import { Card as VanCard, SwipeCell as VanSwipeCell, Search as VanSearch, Swipe as VanSwipe,SwipeItem as VanSwipeItem,NavBar as VanNavBar } from 'vant';
import { Button as VanButton ,Pagination as VanPagination} from 'vant';


const router = useRouter()

const images = reactive([
      "image1","image2","image3","image4"
    ])
function onClickLeft(){
  router.push('/area')
}
</script>

<template>

<van-nav-bar
  title="首页"
  left-text="位置"
  @click-left="onClickLeft"
/>
<van-search v-model="value" placeholder="请输入搜索关键词" />

<van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
  <van-swipe-item v-for="(item,index) in images">
    <div :class="item"></div>
  </van-swipe-item>
   <van-swipe-item>1</van-swipe-item>
  <van-swipe-item>2</van-swipe-item>
  <van-swipe-item>3</van-swipe-item>
  <van-swipe-item>4</van-swipe-item> 
</van-swipe>
<van-swipe-cell>
  <van-card
    num="0"
    price="24.00"
    desc="电影信息"
    title="喜羊羊与灰太狼"
    class="goods-card"
    thumb="../assets/xiyangyang.jpg"
  />
  <template #right>
    <van-button square text="收藏" type="danger" class="collection-button" />
  </template>
</van-swipe-cell>
<van-swipe-cell>
  <van-card
    num="0"
    price="24.00"
    desc="电影信息"
    title="喜羊羊与灰太狼"
    class="goods-card"
    thumb="../assets/xiyangyang.jpg"
  />
  <template #right>
    <van-button square text="收藏" type="danger" class="collection-button" />
  </template>
</van-swipe-cell>
<van-swipe-cell>
  <van-card
    num="0"
    price="24.00"
    desc="电影信息"
    title="喜羊羊与灰太狼"
    class="goods-card"
    thumb="../assets/xiyangyang.jpg"
  />
  <template #right>
    <van-button square text="收藏" type="danger" class="collection-button" />
  </template>
</van-swipe-cell>
<van-pagination v-model="currentPage" :page-count="12" mode="simple" />
</template>

<style scoped>

.image1{
  height: 140px;
  background-size: cover;
  background-repeat: no-repeat;
  background-image: url('../assets/dahuaxiyou.jpeg');
}
.image2{
  height: 140px;
  background-size: cover;
  background-repeat: no-repeat;
  background-image: url('../assets/tianqizhizi.jpeg');
}
.image3{
  height: 140px;
  background-size: cover;
  background-repeat: no-repeat;
  background-image: url('../assets/duizhang.jpeg');
}
.image4{
  height: 140px;
  background-size: cover;
  background-repeat: no-repeat;
  background-image: url('../assets/shenghua.jpeg');
}
.my-swipe .van-swipe-item {
    color: #fff;
    font-size: 20px;
    line-height: 150px;
    text-align: center;
    background-color: #39a9ed;
}
.goods-card {
    margin: 0;
    background-color: white;
  }

  .collection-button {
    height: 100%;
    background-color: yellow;
  }
.read-the-docs {
  color: #888;
}
</style> --> 
<script setup>
import { ref, reactive } from 'vue'
import { useRouter } from "vue-router";
import { Grid as VanGrid, GridItem as VanGridItem ,Swipe as VanSwipe , SwipeItem as VanSwipeItem,NavBar as VanNavBar,
Search as VanSearch,} from 'vant';
const router = useRouter()
function onClickSch(){
  router.push('/search')
}
// function onClickButton(){
//     router.push('/address')
// }
const images = reactive([
      "image1","image2","image3","image4","image5"
    ])

// 广告栏
const imagesList = reactive([
  {icon:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/69c250436545049ccab81c3e32033cf2.png?f=webp&w=216&h=228&bg=FFFFFF",text:"手机",url:"https://m.mi.com/mfbs/dghd/m_universal?_rt=rn&pageid=11997&pdl=mishop&sign=5d8f917b1279d77053288a4c13a52870&spmref=MiShop_M.cms_26.3441276.3&scmref=cms.0.0.0.0.0.0.0"},
  {icon:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/9ea68dee2bfa0e55a82236b0d968e975.png?w=216&h=228&bg=FCEAEA",text:"笔记本热卖",url:"https://m.mi.com/mfbs/dghd/m_universal?_rt=rn&pageid=11212&pdl=mishop&sign=2617d49fa1f63ba7a3de34a2ba0cfe51&spmref=MiShop_M.cms_26.3441277.2&scmref=cms.0.0.0.0.0.0.0"},
  {icon:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/96c780016ea196743905dc93f9249c39.png?w=216&h=228&bg=FDF5E5",text:"电视机热卖",url:"https://m.mi.com/mfbs/dghd/m_universal?_rt=rn&pageid=11859&pdl=mishop&sign=353bc7d6a68760a8d65da60dd306181d&spmref=MiShop_M.cms_26.3441277.3&scmref=cms.0.0.0.0.0.0.0"},
  {icon:"https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/0434594382110f3bd15c90f040d5d542.jpg?f=webp&w=216&h=228&bg=FFFFFF",text:"小米上新",url:"https://s1.mi.com/m/app/hd/index.html?id=product_channel_page&spmref=MiShop_M.cms_26.3441276.5&scmref=cms.0.0.0.0.0.0.0"}
])


</script>

<template>
<div>
<van-search
  v-model="value"
  show-action
  label="搜索"
  placeholder="请输入搜索关键词" to="/search"
  @search="onSearch">
  <van-nav-bar @click-left="onClickSch"/>

   <template #action>
     <div>
    
     </div>
  </template>
</van-search>

<van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
  <van-swipe-item v-for="(item,index) in images">
    <div :class="item"></div>
  </van-swipe-item>
</van-swipe>

<van-grid icon-size="40px">
  <van-grid-item v-for="(item,index) in imagesList" :icon="item.icon" :text="item.text" :url="item.url"/>
</van-grid>

    <div class="color-piece">
<!-- 商品 -->
<div class="frame">
  <div class="iamge01"></div>
  <div class="context">
     <div class="name">
      <div>Xiaomi 13 Ultra</div>
     </div>
     <div class="brief">徕卡光学全焦段四摄| 一英寸可变光圈| 徕卡专业街拍模式</div>
    <div class="price">￥5999<span>起</span><!----></div>
  </div>
  <div>
        <div class="button" > 立即购买</div>
  </div>
</div>
<div class="line"></div>

<div class="frame">
  <div class="iamge02"></div>
  <div class="context">
     <div class="name">
      <div>Redmi Note 12 Turbo</div>
     </div>
     <div class="brief">狂暴引擎 超强性能释放</div>
    <div class="price">￥1899<span>起</span><!----></div>
  </div>
  <div>
        <div class="button"> 立即购买</div>
  </div>
</div>
<div class="line"></div>

<div class="frame">
  <div class="iamge03"></div>
  <div class="context">
     <div class="name">
      <div>Xiaomi 13</div>
     </div>
     <div class="brief">全新第二代骁龙8｜徕卡专业光学镜头｜徕卡原生双画质 | 6.36″超窄边屏幕｜67W小米澎湃秒充｜徕卡75mm长焦镜头</div>
    <div class="price">￥3999<span>起</span><!----></div>
  </div>
  <div>
        <div class="button"> 立即购买</div>
  </div>
</div>
<div class="line"></div>

<div class="frame">

  <div class="iamge04"></div>
  <div class="context">
     <div class="name">
      <div>Xiaomi 13 限量定制色</div>
     </div>
     <div class="brief">全新第二代骁龙8｜徕卡专业光学镜头｜徕卡原生双画质 | 6.36″超窄边屏幕｜67W小米澎湃秒充｜徕卡75mm长焦镜头</div>
    <div class="price">￥4999<span>起</span><!----></div>
  </div>
  <div>
        <div class="button"> 立即购买</div>
  </div>


</div>
<div class="line"></div>

<div class="frame">

  <div class="iamge05"></div>
  <div class="context">
     <div class="name">
      <div>Redmi K60E</div>
     </div>
     <div class="brief">天玑8200丨2K 旗舰直屏丨5500mAh长续航</div>
    <div class="price">￥2199<span>起</span><!----></div>
  </div>
  <div>
        <div class="button"> 立即购买</div>
        
  </div>


</div>
<div class="line"></div>

<div class="frame">

  <div class="iamge06"></div>
  <div class="context">
     <div class="name">
      <div>Redmi G 游戏本 2022</div>
     </div>
     <div class="brief">16英寸 2.5K 165Hz 电竞大屏</div>
    <div class="price">￥7499<span>起</span><!----></div>
  </div>
  <div>
        <div class="button"> 立即购买</div>
  </div>


</div>
<div class="line"></div>

<div class="frame">
  <div class="iamge07"></div>
  <div class="context">
     <div class="name">
      <div>RedmiBook Pro 15 2022 锐龙版</div>
     </div>
     <div class="brief">可选全新锐龙7 6800H处理器，3.2K 90Hz高清屏，RTX 2050高性能独立显卡，CNC一体精雕工艺</div>
    <div class="price">￥5499<span>起</span><!----></div>
  </div>
  <div>
        <div class="button"> 立即购买</div>
  </div>

</div>
<div class="line"></div>

<div class="frame">
  <div class="iamge08"></div>
  <div class="context">
     <div class="name">
      <div>小米小爱音箱 Pro</div>
     </div>
     <div class="brief">澎湃低音，语音遥控传统家电</div>
    <div class="price">￥299<span>起</span><!----></div>
  </div>
  <div>
        <div class="button"> 立即购买</div>
  </div>

</div>
<div class="line"></div>


<div class="frame">
  <div class="iamge09"></div>
  <div class="context">
     <div class="name">
      <div>平衡车</div>
     </div>
     <div class="brief">年轻人的酷玩具</div>
    <div class="price">￥2199<span>起</span><!----></div>
  </div>
  <div>
        <div class="button"> 立即购买</div>
  </div>
  
</div>
<div class="line"></div>

<div class="frame">
  <div class="iamge10"></div>
  <div class="context">
     <div class="name">
      <div>小米电视 大师 65英寸OLED</div>
     </div>
     <div class="brief">OLED自发光屏 | 百万级对比度 | 双120Hz高刷</div>
    <div class="price">￥9999<span>起</span><!----></div>
  </div>
  <div>
        <div class="button"> 立即购买</div>
  </div>
  
</div>
<div class="line"></div>

<div class="blank">
</div>
    </div>
</div>




</template>
<style scoped>
/* 布局 */

.color-piece{
  overflow-y: scroll;
  height: 480px;
}
.frame{
  display:flex;
  flex-direction: row;
}
.iamge01{
  margin-top: 16px;
  margin-left: 16px;
  width: 200px;
  height: 60px;
  background: url("https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202304171628_6486482f87e32aa3b03cfab5928831b0.jpg?thumb=1&q=90&w=344&h=280");
  background-size:cover ;
  background-repeat:no-repeat;
}
.iamge02{
  margin-top: 16px;
  margin-left: 16px;
  width: 70px;
  height: 60px;
  background: url("https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202303281131_cf3ff6ce70177560f3b9f95bd48fc575.jpg?thumb=1&q=90&w=344&h=280");
  background-size:cover ;
  background-repeat:no-repeat;
}
.iamge03{
  margin-top: 16px;
  margin-left: 16px;
  width: 200px;
  height: 60px;
  background: url("https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202212232345_1322e81f2f5384fd88baa8c60b5cad4e.jpg?thumb=1&q=90&w=344&h=280");
  background-size:cover ;
  background-repeat:no-repeat;
}
.iamge04{
  margin-top: 16px;
  margin-left: 16px;
  width: 200px;
  height: 60px;
  background: url("https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202212232348_5facedab702fee101581c9124af1b89d.jpg?thumb=1&q=90&w=344&h=280");
  background-size:cover ;
  background-repeat:no-repeat;
}
.iamge05{
  margin-top: 16px;
  margin-left: 16px;
  width: 100px;
  height: 60px;
  background: url("https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202212261500_edb59e2a391fc8b99f706122c47f3345.jpg?thumb=1&q=90&w=344&h=280");
  background-size:cover ;
  background-repeat:no-repeat;
}
.iamge06{
  margin-top: 16px;
  margin-left: 16px;
  width: 70px;
  height: 50px;
  background: url("https://cdn.cnbj1.fds.api.mi-img.com/nr-pub/202207191154_4d238e772ff74153180955e54dbb0366.jpg?thumb=1&q=90&w=344&h=280");
  background-size:cover ;
  background-repeat:no-repeat;
}
.iamge07{
  margin-top: 16px;
  margin-left: 16px;
  width: 70px;
  height: 50px;
  background: url("https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/14ad4f16c1b23168b0accb2ae439417e.jpg?f=webp");
  background-size:cover ;
  background-repeat:no-repeat;
}
.iamge08{
  margin-top: 16px;
  margin-left: 16px;
 width: 70px;
  height: 70px;
  background: url("https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/159e9dc6948ff33fb231c10c0c7700f1.jpg?f=webp&w=330&h=330&thumb=1");
  background-size:cover ;
  background-repeat:no-repeat;
}
.iamge09{
  margin-top: 16px;
  margin-left: 16px;
 width: 70px;
  height: 70px;
  background: url("https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/2e3ae4b083c0c5d3f25145a10ea513cb.jpg?f=webp&w=330&h=330&thumb=1");
  background-size:cover ;
  background-repeat:no-repeat;
}
.iamge10{
  margin-top: 16px;
  margin-left: 16px;
  width: 70px;
  height: 60px;
  background: url("https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/42deca67a6b5a057e5384f79584d282d.jpg?f=webp&w=505&h=505&thumb=1");
  background-size:cover ;
  background-repeat:no-repeat;
}
.name{
  display: flex;
  flex-direction: row;
  font-size: 16px;
}
.brief{
  margin-top: 2px;
  font-size: 8px;
  color: #969696;
  overflow:hidden; 
  text-overflow:ellipsis; 
  white-space:nowrap; 
}
.line{
  margin-top:16px ;
  margin-left: 10px;
  margin-right: 10px;
  border-top:1px solid #d1d1d1 ;
}
.price{
  margin-top: 6px;
  display: flex;
  flex-direction: row;
  font-size: 16px;
  color: #ec0303;
}
.context{
  display: flex;
  flex-direction: column;
  margin-left: 12px;
  margin-top: 16px;
  width: 200px;
}
.button{
  margin-top: 40px;
  border: 1px solid #dc5b2c;
  color: #dc5b2c;
  font-size: 16px;
  width: 80px;
  height: 30px;
  border-radius: 4px;
  text-align: center;
  line-height: 30px;
}
.name-right{
  margin-top: 4px;
  margin-left: 4px;
  padding: 0px 3px;
  color: #ffffff;
  background-color: #d2d2d2;
  border-radius: 4px;
  line-height: 14px;
  height: 14px;
  font-size: 14px;
}

.image1{
  height: 180px;
  background-size:cover;
  background-repeat: no-repeat;
  background-image: url('https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/fac6082a5a2e27bf003163c8ea9ae150.png?f=webp&w=1080&h=540&bg=10');
}
.image2{
  height: 180px;
  background-size:cover;
  background-repeat: no-repeat;
  background-image: url('https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/6e95960cdf5776933de70392441d6357.jpeg?f=webp&w=1080&h=540&bg=CEE7FB');
}
.image3{
  height: 180px;
  background-size:cover;
  background-repeat: no-repeat;
  background-image: url('https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/387d1bad240308862741ced9bcaf2f2a.png?f=webp&w=1080&h=540&bg=0');
}
.image4{
  height: 180px;
  background-size:cover;
  background-repeat: no-repeat;
  background-image: url('https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/d3223bf500e3c3db53dd72de11824006.jpg?f=webp&w=1080&h=540&bg=50102');
}
.image5{
  height: 180px;
  background-size:cover;
  background-repeat: no-repeat;
  background-image: url('https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/744dd4674e7e07fbd763fb7e98e753a6.jpg?f=webp&w=1080&h=540&bg=9C7E5A');
}
.my-swipe .van-swipe-item {
    color: #fff;
    font-size: 20px;
    line-height: 150px;
    text-align: center;
    background-color: #39a9ed;
}
.read-the-docs {
  color: #888;
}

.blank{
  height: 50px;
}
</style>
