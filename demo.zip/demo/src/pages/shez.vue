<script setup>
defineProps({
 msg: String,
})
import { Cell as VanCell ,Button as VanButton} from 'vant';
//返回主页面
function onClickButton(){
   router.push('/mine')
}
</script>

<template>
     <van-button to="/mine">返回</van-button>
    <van-cell title="切换账号" icon="friends" is-link/>
    <van-cell title="退出登录" icon="umbrella-circle" is-link/>

</template>

<style scoped>

</style>
