<script setup>
defineProps({
 msg: String,
})
import { ref } from 'vue';
import { CouponCell as VanCouponCell,Popup as VanPopup, CouponList as VanCouponList,Button as VanButton } from 'vant';

//返回主页面
function onClickButton(){
   router.push('/mine')
 }
//优惠券信息
const coupon = {
    available:1,
    condition: '无门槛',
      reason: '',
      value: 150,
      name: '商品优惠券',
      startAt: 1489104000,
      endAt: 1514592000,
      valueDesc: '10',
      unitDesc: '元',
}
        const coupons = ref([coupon]);
    const showList = ref(false);
    const chosenCoupon = ref(5);

    const onChange = (index) => {
      showList.value = false;
      chosenCoupon.value = index;
    };
    const onExchange = (code) => {
      coupons.value.push(coupon);
    };

</script>


<template>
     <van-button to="/mine">返回</van-button>
    <!-- 优惠券单元格 -->
<van-coupon-cell
  :coupons="coupons"
  :chosen-coupon="chosenCoupon"
  @click="showList = true"
/>
<!-- 优惠券列表 -->
<van-popup
  v-model:show="showList"
  round
  position="bottom"
  style="height: 90%; padding-top: 4px;"
>
  <van-coupon-list
    :coupons="coupons"
    :chosen-coupon="chosenCoupon"
    :disabled-coupons="disabledCoupons"
    @change="onChange"
    @exchange="onExchange"
  />
</van-popup>

</template>

<style scoped>

</style>
