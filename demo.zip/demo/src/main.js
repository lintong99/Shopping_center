import { createApp } from 'vue'
import { ConfigProvider ,Button,Icon} from 'vant';

import App from './App.vue'
import router from './router/index'


import 'amfe-flexible'
import 'vant/lib/index.css'
createApp(App)
  .use(router)

  .use(Icon)
  .use(Button)
  .use(ConfigProvider)
  .mount('#app')

