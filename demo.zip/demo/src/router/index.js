import { createRouter, createWebHashHistory, } from 'vue-router'
import Home from '../pages/home.vue'
import About from '../pages/about.vue'
import Mine from '../pages/mine.vue'
import Search from '../pages/search.vue'
import Cart from '../pages/cart.vue'
import Kefu from '../pages/kefu.vue'
import Hula from '../pages/hula.vue'
import Local from '../pages/local.vue'
import Youh from '../pages/youh.vue'
import Shez from '../pages/shez.vue'


const routes = [
  {
    path: '/home',
    name: 'Home',
    component: Home
  },
  {
    path: '/about',
    name: 'About',
    component: About
  },
  {
    path: '/mine',
    name: 'Mine',
    component: Mine
  },
  {
    path: '/cart',
    name: 'Cart',
    component: Cart
  },
  {
    path: '/search',
    name: 'Search',
    component: Search
  },
  {
    path: '/kefu',
     name: 'Kefu',
    component: Kefu
    },
     {
    path: '/hula',
    name: 'Hula',
    component: Hula
    },
    {
    path: '/local',
    name: 'Local',
    component: Local
     },
     {
     path: '/youh',
    name: 'Youh',
    component: Youh
     },
    {
     path: '/shez',
     name: 'Shez',
    component: Shez
    },  
  
]
const router = createRouter(
  {
    history: createWebHashHistory(), routes
  }
)

export default router
