<script setup>
    import { ref,reactive } from 'vue'
    let name =ref('确定')
    let booklist=reactive([{book:'三国'},{book:'三国'},{book:'三国'},{book:'三国'},{book:'三国'}])

    function showWindow(){
        alert("呵呵")
    }
</script>

<template>

    <div>
        <div v-for="(item,index) in booklist" :key="index">{{ item.book }}</div>
        <div>{{ name }}</div>
        <input type="text" v-model="name" >
        <input type="button" value="name" @click="showWindow">
    </div>
</template>

<style scoped>
    
</style>
