<script setup>
defineProps({
  msg: String,
})
</script>

<template>
  <div>
    <div>{{msg}}</div>
    <input type="text" :value="msg" @click="showWindow">
  </div>
</template>

<style scoped>
.read-the-docs {
  color: #f70303;
}
.msg{
  color: #23f318;
}
</style>
