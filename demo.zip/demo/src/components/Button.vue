<script setup>
    const props= defineProps({
        msg:String,
    })
    function showWindow(){
        alert(props.msg)
    }
</script>

<template>
    <input type="button" value="确定" class="button1">
    <input type="button" value="取消" class="button2">
    <input type="button" value="msg" @click="showWindow">

</template>

<style scoped>
    .button1{
        width: 100px;
        height: 100px;
    }
    .button2{
        width: 100px;
        height: 100px;
    }
</style>
